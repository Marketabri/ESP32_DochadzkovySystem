<?php
header('Content-Type: application/json');

$servername = "86.110.243.72";
$username = "id041500";
$password = "M4iufPk7aUHqePyjxeYmGg";
$dbname = "id041500db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["success" => false, "error" => "Chyba pripojenia k databáze"]);
    exit();
}

// Načítanie dát z requestu
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['ids']) || !is_array($data['ids'])) {
    echo json_encode(["success" => false, "error" => "Neplatné dáta."]);
    exit();
}

$ids = array_map('intval', $data['ids']); // Prevencia SQL injection
$idList = implode(',', $ids);

// Mazanie záznamov
$sql = "DELETE FROM RFID WHERE id IN ($idList)";

if ($conn->query($sql)) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $conn->error]);
}

$conn->close();
?>
