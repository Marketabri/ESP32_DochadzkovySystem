<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "86.110.243.72";
$username = "id041500";
$password = "M4iufPk7aUHqePyjxeYmGg";
$dbname = "id041500db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(["error" => "Chyba pripojenia k DB"]);
    exit();
}

if (isset($_POST['id']) && isset($_POST['login'])) {
    $id = intval($_POST['id']);
    $login = $_POST['login'];

    $stmt = $conn->prepare("UPDATE RFID SET login = ? WHERE id = ?");
    $stmt->bind_param("si", $login, $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["error" => "Chyba pri aktualizácii: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["error" => "Chýbajúce údaje"]);
}

$conn->close();
?>
