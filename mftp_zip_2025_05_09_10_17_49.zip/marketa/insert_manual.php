<?php
// Nastavenie pre lepšie ladenie počas vývoja
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Pripojenie k databáze
$servername = "86.110.243.72";
$username = "id041500";
$password = "M4iufPk7aUHqePyjxeYmGg";
$dbname = "id041500db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["success" => false, "error" => "Chyba pripojenia k databáze: " . $conn->connect_error]);
    exit();
}

// Načítanie dát z POST
$meno = $_POST['meno'] ?? '';
$priezvisko = $_POST['priezvisko'] ?? '';
$cardID = $_POST['cardID'] ?? '';
$login = date('Y-m-d H:i:s');

// Overenie povinných polí
if (empty($meno) || empty($priezvisko)) {
    echo json_encode(['success' => false, 'error' => 'Meno a priezvisko sú povinné.']);
    exit();
}

// Príprava a vykonanie dotazu (POZOR na názov tabuľky - správne veľké písmená!)
$stmt = $conn->prepare("INSERT INTO RFID (meno, priezvisko, cardID, login) VALUES (?, ?, ?, ?)");

if ($stmt === false) {
    echo json_encode(['success' => false, 'error' => 'Chyba v SQL príprave: ' . $conn->error]);
    exit();
}

$stmt->bind_param("ssss", $meno, $priezvisko, $cardID, $login);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Chyba pri ukladaní: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
