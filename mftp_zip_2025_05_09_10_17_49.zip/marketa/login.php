<?php
session_start();

// Ak je už prihlásený, presmeruj
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header("Location: index.php");
    exit();
}

// Kontrola prihlásenia
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // 🔐 Tu zmeň svoje heslo a meno
    if ($username === "admin" && $password === "1234") {
        $_SESSION['logged_in'] = true;
        header("Location: index.php");
        exit();
    } else {
        $error = "Nesprávne meno alebo heslo!";
    }
}
?>

<!DOCTYPE html>
<html lang="sk">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="styles.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="manifest" href="manifest.json">
  <link rel="icon" href="icons/icon-192.png">
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>
<body>


  <!-- LOGIN BOX -->
  <div class="login-box">
    <h2>Prihlásenie do dochádzkového systému</h2>
    <!-- ANIMÁCIA V POZADÍ -->
 <!-- Lottie animácia počítača -->
<!-- Lottie animácia počítača -->
<div class="lottie-pc-right" style="position: absolute; top: 50%; right: -60px; transform: translateY(-50%); z-index: 0; pointer-events: none; width: 300px;">
  <lottie-player
    src="https://assets5.lottiefiles.com/packages/lf20_w51pcehl.json"
    background="transparent" speed="1" loop autoplay>
  </lottie-player>
</div>

    <?php if (!empty($error)): ?>
      <p class="login-error"><?= $error ?></p>
    <?php endif; ?>

    <form method="POST">
      <input type="text" name="username" placeholder="Používateľské meno" required>
      <input type="password" name="password" placeholder="Heslo" required>
      <button type="submit">Prihlásiť sa</button>
    </form>
  </div>


</body>
</html>
