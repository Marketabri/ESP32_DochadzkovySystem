<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="sk">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#204E3A">
  <link rel="manifest" href="manifest.json">
  <link rel="icon" href="icons/icon-192.png">



  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
  <title>RFID záznamy</title>
 
</head>
<body>
 <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #000;
      color: white;
      overflow-x: hidden;
    }
    h2 {
      color: white;
      text-align: center;
      font-size: 32px;
      margin-top: 20px;
    }
    .container-custom {
      max-width: 1100px;
      margin: 0 auto;
      padding: 20px;
      background: rgba(30,30,30,0.95);
      border-radius: 12px;
    }
    .top-controls {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      gap: 10px;
      margin-bottom: 15px;
      flex-wrap: wrap;
    }
    .table-wrapper {
      max-height: 60vh;
      overflow-y: auto;
      background-color: white;
      color: black;
      border-radius: 12px;
      padding: 10px;
    }
    .table-wrapper::-webkit-scrollbar {
      width: 8px;
    }
    .table-wrapper::-webkit-scrollbar-thumb {
      background-color: rgba(0,0,0,0.2);
      border-radius: 5px;
    }
    .btn {
      border-radius: 30px;
      padding: 6px 16px;
      font-weight: 500;
    }
    .btn-success {
      background-color: #708238;
      border: none;
    }
    .btn-danger {
      background-color: #e74c3c;
    }
    .btn-primary {
      background-color: #3498db;
    }
    .lottie-left, .lottie-right {
      position: fixed;
      top: 50%;
      transform: translateY(-50%);
      width: 15px;
      height: 15px;
      z-index: 1;
      opacity: 0.6;
      pointer-events: none;
    }
    @media screen and (max-width: 768px) {
  .top-controls {
    flex-direction: column;
    align-items: stretch;
  }

  .top-controls > * {
    width: 100%;
    margin-bottom: 10px;
  }

  h2 {
    font-size: 24px;
  }

  .table-wrapper {
    padding: 5px;
    font-size: 14px;
  }

  .btn {
    font-size: 14px;
  }
}

   
  </style>



  <h2>RFID Dochádzka študentov</h2>
 

  <div class="container-custom mt-4">
    <div class="top-controls">
      <div class="d-flex flex-column" style="max-width: 200px;">
  <label for="filter-card" class="form-label text-white mb-1">Filtrovať podľa Card ID</label>
  <input type="text" id="filter-card" class="form-control" placeholder="Zadaj ID karty...">
</div>


      <button class="btn btn-outline-light btn-sm" onclick="manualRefresh()">🔁 Obnoviť</button>
      <button class="btn btn-danger btn-sm" onclick="printTable()">🖨️ Tlačiť</button>
      <button class="btn btn-success btn-sm" onclick="exportTableToExcel('data-table', 'rfid_zaznamy')">📁 Export</button>
      <button class="btn btn-danger btn-sm" onclick="deleteSelected()">🗑️ Vymazať označené</button>

      <a href="logout.php" class="btn btn-outline-light btn-sm">Odhlásiť sa</a>
    </div>
     <div class="card bg-dark text-white mb-3">
  <div class="card-body">
    <h5 class="card-title">Manuálne pridať záznam</h5>
    <form id="manualForm" class="row g-3">
      <div class="col-md-4">
        <input type="text" class="form-control" name="meno" placeholder="Meno" required>
      </div>
      <div class="col-md-4">
        <input type="text" class="form-control" name="priezvisko" placeholder="Priezvisko" required>
      </div>
      <div class="col-md-4">
        <input type="text" class="form-control" name="cardID" placeholder="Card ID (voliteľné)">
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-primary">Pridať záznam</button>
      </div>
    </form>
  </div>
</div>

    <div class="table-wrapper">
      <table id="data-table" class="table table-striped table-bordered align-middle">
     <thead>
  <tr>
    <th><input type="checkbox" id="select-all"></th> <!-- Pridaj na začiatok -->
    <th>Meno</th>
    <th>Priezvisko</th>
    <th>Card ID</th>
    <th>Login</th>
    <th>Úprava</th>
  </tr>
</thead>
        <tbody></tbody>
      </table>
    </div>
  </div>

  <script>
    fetch('get_data.php')
      .then(res => res.json())
      .then(data => {
  const tbody = document.querySelector('#data-table tbody');
  data.forEach(row => {
    const tr = document.createElement('tr');

    // Formátovanie dátumu a času
    const loginDate = new Date(row.login);
    const day = String(loginDate.getDate()).padStart(2, '0');
    const month = String(loginDate.getMonth() + 1).padStart(2, '0');
    const year = loginDate.getFullYear();
    const hours = String(loginDate.getHours()).padStart(2, '0');
    const minutes = String(loginDate.getMinutes()).padStart(2, '0');
    const formattedLogin = `${hours}:${minutes} (${day}.${month}.${year})`;

    tr.innerHTML = `
    <td><input type="checkbox" class="row-checkbox" data-id="${row.id}"></td>
      <td>${row.meno}</td>
      <td>${row.priezvisko}</td>
      <td>${row.cardID}</td>
      <td class="fw-bold">${formattedLogin}</td>
      

      <td>
        <button class="btn btn-success btn-sm me-2" onclick="editRecord(${row.id}, '${row.login}')"><i class="bi bi-pencil-square"></i> Upraviť</button>
        <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.id})"><i class="bi bi-trash"></i> Zmazať</button>
      </td>`;
    tbody.appendChild(tr);
  });
});


    const filterInput = document.getElementById("filter-card");
    filterInput.addEventListener("input", () => {
      const filter = filterInput.value.toLowerCase();
      localStorage.setItem("filter_cardID", filter);
      const rows = document.querySelectorAll("#data-table tbody tr");
      rows.forEach(row => {
        const cardID = row.children[2].textContent.toLowerCase();
        row.style.display = cardID.includes(filter) ? "" : "none";
      });
    });

    window.addEventListener("DOMContentLoaded", () => {
      const savedFilter = localStorage.getItem("filter_cardID") || "";
      filterInput.value = savedFilter;
      const rows = document.querySelectorAll("#data-table tbody tr");
      rows.forEach(row => {
        const cardID = row.children[2].textContent.toLowerCase();
        row.style.display = cardID.includes(savedFilter) ? "" : "none";
      });
    });

    function manualRefresh() { location.reload(); }

    function exportTableToExcel(tableID, filename = '') {
      const table = document.getElementById(tableID).outerHTML.replace(/ /g, '%20');
      const link = document.createElement("a");
      link.href = 'data:application/vnd.ms-excel,' + table;
      link.download = filename || 'excel_data.xls';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    function printTable() {
      const content = document.querySelector('.table-wrapper').innerHTML;
      const win = window.open('', '', 'height=600,width=800');
      win.document.write('<html><head><title>Výpis</title></head><body>');
      win.document.write(content);
      win.document.write('</body></html>');
      win.document.close();
      win.print();
    }

    function deleteRecord(id) {
      if (confirm("Naozaj chceš zmazať tento záznam?")) {
        fetch('delete_record.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'id=' + encodeURIComponent(id)
        })
          .then(res => res.json())
          .then(result => {
            alert(result.success ? "Záznam zmazaný" : "Chyba: " + result.error);
            location.reload();
          });
      }
    }

    function editRecord(id, currentLogin) {
      const newLogin = prompt("Zadaj nový čas prihlásenia:", currentLogin);
      if (newLogin) {
        fetch('update_record.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `id=${id}&login=${encodeURIComponent(newLogin)}`
        })
          .then(res => res.json())
          .then(result => {
            alert(result.success ? "Úspešne zmenené" : "Chyba: " + result.error);
            location.reload();
          });
      }
    }
    document.getElementById("manualForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('insert_manual.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(result => {
    alert(result.success ? "Záznam bol pridaný" : "Chyba: " + result.error);
    if (result.success) location.reload();
  });
});
function deleteSelected() {
  const checkboxes = document.querySelectorAll('.row-checkbox:checked');
  if (checkboxes.length === 0) {
    alert("Musíš označiť aspoň jeden záznam.");
    return;
  }

  if (!confirm("Naozaj chceš zmazať vybrané záznamy?")) return;

  const ids = Array.from(checkboxes).map(cb => cb.getAttribute('data-id'));

  fetch('delete_multiple.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ids: ids})
  })
  .then(res => res.json())
  .then(result => {
    if (result.success) {
      alert("Vymazané úspešne");
      location.reload();
    } else {
      alert("Chyba pri mazaní: " + result.error);
    }
  });
}


  </script>

  <script>
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('service-worker.js')
        .then(reg => console.log('✅ Service Worker registrovaný:', reg))
        .catch(err => console.error('❌ Chyba pri registrácii SW:', err));
    }
  </script>
  


<lottie-player
  src="https://assets10.lottiefiles.com/packages/lf20_j1adxtyb.json"
  background="transparent"
  speed="1"
 style="position: fixed; top: 20px; left: 20px; width: 200px; height: 200px; z-index: 0; opacity: 0.4;"
  loop autoplay>
</lottie-player>

<lottie-player
  src="https://assets10.lottiefiles.com/packages/lf20_9cyyl8i4.json"
  background="transparent"
  speed="1"
  style="position: fixed; bottom: 0; right: 0; width: 250px; height: 350px; z-index: 0; opacity: 0.3;"
  loop autoplay>
</lottie-player>



  <?php include 'footer.html'; ?>
</body>
</html>
