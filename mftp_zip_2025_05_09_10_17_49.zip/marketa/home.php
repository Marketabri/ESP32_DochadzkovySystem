<!DOCTYPE html>
<html lang="sk">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dochádzkový systém - Úvod</title>

  <!-- Lottie -->
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

  <!-- Štýly -->
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #0d0d0d;
      color: white;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 80vh;
      text-align: center;
    }

    h1 {
      font-size: 3rem;
      color: #8cc84b;
      margin-bottom: 0.5rem;
    }

    p {
      font-size: 1.2rem;
      max-width: 700px;
      margin: 1rem 0 2rem 0;
      color: #cccccc;
    }

    .button {
      background-color: #8cc84b;
      color: #fff;
      border: none;
      padding: 15px 40px;
      font-size: 1.1rem;
      border-radius: 50px;
      text-decoration: none;
      transition: 0.3s;
    }

    .button:hover {
      background-color: #76aa3d;
    }

    lottie-player {
      width: 400px;
      height: 400px;
      margin-bottom: 15px;
    }
  </style>
</head>

<body>

  <lottie-player
    src="https://assets3.lottiefiles.com/packages/lf20_HpFqiS.json"
    background="transparent"
    speed="1"
    loop
    autoplay>
  </lottie-player>

  <h1>RFID Dochádzkový systém pre školy</h1>
  <p>
    Moderné riešenie na evidenciu príchodov študentov pomocou ID kariet a ESP32. Všetky záznamy sú bezpečne uložené a prístupné online.
  </p>

  <a class="button" href="login.php">Prihlásiť sa</a>

</body>
</html>
